addpath('lib');
addpath('tests');
addpath('.');
