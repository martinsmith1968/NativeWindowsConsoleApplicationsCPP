Embed Figlet
============
|Build Status|

``embedFiglet`` is a C++ library which implement a subset of Figlet
capability (http://www.figlet.org). No configuration or font file are
necessary, moveover, the fonts are stored in structure initalized at
compile time.

Online documentation
~~~~~~~~~~~~~~~~~~~~

Available `here <http://ebertolazzi.github.io/embedFiglet>`__

Author
------

| Enrico Bertolazzi
| Dipartimento di Ingegneria Industriale
| Università degli Studi di Trento
| email: enrico.bertolazzi@unitn.it
| homepage: https://e.bertolazzi.dii.unitn.it

.. |Build Status| image:: https://travis-ci.org/ebertolazzi/embedFiglet.svg?branch=master
   :target: https://travis-ci.org/ebertolazzi/embedFiglet
